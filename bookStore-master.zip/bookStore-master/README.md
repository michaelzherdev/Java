# bookStore
test web project JSP &amp; JPA with using of following technologies:
Java 8
Tomcat 8
JPA (EclipseLink 2.5.2)
JSP & Servlets
HTML & CSS
