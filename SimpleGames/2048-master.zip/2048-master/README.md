# 2048
game 2048 on JavaFX.
Based on code of https://github.com/bulenkov/2048
